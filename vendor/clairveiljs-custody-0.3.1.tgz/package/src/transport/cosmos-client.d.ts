import type { WalletPrivacyIdentity, PublicPrivacyIdentity } from '../wallet-kernel/identity.js';
import type { ChainActor } from '../chain-wallet/index.js';
import type {
  PrivacyScanValidationStateV2,
  PrivacyScanValidationStateSnapshotV2,
  ValidatedPrivacyScanPageV2
} from "../privacy/scan.js";
import type { ValidatedDisclosureConfigV1 } from "../privacy/network-config.js";
import type { PrivacyStateAdapter } from "./privacy-state.js";

export * from "../core/crypto.js";
export * from "../core/disclosure.js";
export * from "../core/errors.js";
export * from "../core/note.js";
export * from "../privacy/payload.js";
export * from "../privacy/circuit-config.js";
export * from "../privacy/network-config.js";
export * from "../privacy/planner.js";
export * from "../privacy/prover.js";
export * from "../privacy/reservation.js";
export * from "../privacy/scan.js";
export * from "../privacy/merkle-path.js";
export * from "../privacy/note-store.js";
export * from "../core/schemas.js";
export * from "../wallet/adapter.js";
export * from "./privacy-state.js";
export {
  UserDisclosureMode,
  userDisclosureModeFromJSON,
  userDisclosureModeToJSON
} from "../generated/clairveil/privacy/v1/tx.js";
export type {
  AssetRegistryEntryV1,
  CircuitIdentity,
  CircuitSetIdentity,
  PrivacyScanCursorV1,
  PrivacyScanOutputV2,
  PrivacyScanSummaryV2
} from "../generated/clairveil/privacy/v1/genesis.js";
export type {
  BatchTransferOutput,
  MsgBatchTransfer as MsgBatchTransferMessage,
  MsgDeposit as MsgDepositMessage,
  MsgTransfer as MsgTransferMessage,
  MsgWithdraw as MsgWithdrawMessage,
  MsgBatchTransferResponse,
  MsgDepositResponse,
  MsgTransferResponse,
  MsgWithdrawResponse
} from "../generated/clairveil/privacy/v1/tx.js";
export type {
  QueryAssetByDenomResponse,
  QueryAssetByIDResponse,
  QueryAuditConfigResponse,
  QueryCheckNullifierResponse,
  QueryCircuitConfigResponse,
  QueryCommitmentInfoResponse,
  QueryDisclosureConfigResponse,
  QueryMerklePathResponse,
  QueryPrivacyEvent,
  QueryPrivacyEventAttribute,
  QueryPrivacyEventsResponse,
  QueryPrivacyScanResponse,
  QueryReserveResponse,
  QueryTreeStateResponse
} from "../generated/clairveil/privacy/v1/query.js";

import type { Base64, ClairAddress, Hex, PrivacyMaterial, ShieldedAddress } from "../core/crypto.js";
import type { CoinString, DepositMaterial, FoundNote } from "../core/note.js";
import type {
  PreparedTransferPayload,
  PreparedTransferPayloadInput,
  PreparedTransferProof,
  PreparedWithdrawPayload,
  PreparedWithdrawProof,
  PreparedWithdrawProverPayload,
  PreparedWithdrawProverPayloadInput,
  PreparedWithdrawProverPayloadResult,
  RelayWithdrawPayloadBuildResult,
  RelayWithdrawRelayOptions,
  TransferInputSelection,
  TransferMessage,
  TransferMessageBuildResult,
  WithdrawMessage,
  WithdrawMessageBuildResult
} from "../privacy/payload.js";
import type {
  PreparedBatchTransferPayload,
  PreparedBatchTransferProof
} from "../privacy/batch-transfer.js";
import type { TransferBatchPlan, TransferPlan, WithdrawPlan } from "../privacy/planner.js";
import type { BatchTransferProverAdapter, ProverAdapter } from "../privacy/prover.js";
import type { NoteReservationManager, ReservationBatch } from "../privacy/reservation.js";
import type { ScanResult } from "../privacy/scan.js";
import type { VerifiedCommitmentPathSnapshot } from "../privacy/merkle-path.js";
import type { MemoryNoteStore } from "../privacy/note-store.js";
import type { WalletAdapterLike } from "../wallet/adapter.js";
import type {
  NormalizedAssetRegistryEntryV1,
  NormalizedAssetRegistryQueryResponseV1
} from "../privacy/asset-registry.js";
import type {
  CircuitSetIdentityV1,
  ValidatedCircuitConfigV1
} from "../privacy/circuit-config.js";
import type {
  MsgBatchTransfer as MsgBatchTransferMessage,
  MsgDeposit as MsgDepositMessage
} from "../generated/clairveil/privacy/v1/tx.js";

export const msgDepositTypeUrl: "/clairveil.privacy.v1.MsgDeposit";
export const msgBatchTransferTypeUrl: "/clairveil.privacy.v1.MsgBatchTransfer";
export const msgTransferTypeUrl: "/clairveil.privacy.v1.MsgTransfer";
export const msgWithdrawTypeUrl: "/clairveil.privacy.v1.MsgWithdraw";

export const MsgDeposit: typeof import("../generated/clairveil/privacy/v1/tx.js").MsgDeposit;
export const MsgBatchTransfer: typeof import("../generated/clairveil/privacy/v1/tx.js").MsgBatchTransfer;
export const MsgTransfer: typeof import("../generated/clairveil/privacy/v1/tx.js").MsgTransfer;
export const MsgWithdraw: typeof import("../generated/clairveil/privacy/v1/tx.js").MsgWithdraw;

/**
 * Structural protobuf codec accepted by the Clairveil Cosmos registry.
 * Kept local so consumers do not inherit CosmJS' optional code-generator types.
 */
export interface ClairveilRegistryCodecBase {
  readonly typeUrl?: string;
  readonly encode: (...args: any[]) => { finish(): Uint8Array };
  readonly decode: (...args: any[]) => any;
}

export type ClairveilRegistryGeneratedType = ClairveilRegistryCodecBase & (
  | {
      readonly fromPartial: (...args: any[]) => any;
      readonly create?: (...args: any[]) => any;
    }
  | {
      readonly create: (...args: any[]) => any;
      readonly fromPartial?: (...args: any[]) => any;
    }
);

export interface ClairveilRegistryEncodeObject<T = unknown> {
  readonly typeUrl: string;
  readonly value: T;
}

export interface ClairveilRegistryDecodeObject {
  readonly typeUrl: string;
  readonly value: Uint8Array;
}

/** Public, dependency-safe structural surface of CosmJS Registry. */
export interface ClairveilRegistry {
  register(typeUrl: string, type: ClairveilRegistryGeneratedType): void;
  lookupType(typeUrl: string): ClairveilRegistryGeneratedType | undefined;
  encode<T>(encodeObject: ClairveilRegistryEncodeObject<T>): Uint8Array;
  encodeAsAny<T>(encodeObject: ClairveilRegistryEncodeObject<T>): ClairveilRegistryDecodeObject;
  encodeTxBody(txBodyFields: {
    readonly messages: readonly ClairveilRegistryEncodeObject[];
    readonly memo?: string;
    readonly timeoutHeight?: bigint;
    readonly extensionOptions?: readonly ClairveilRegistryDecodeObject[];
    readonly nonCriticalExtensionOptions?: readonly ClairveilRegistryDecodeObject[];
  }): Uint8Array;
  decode(decodeObject: ClairveilRegistryDecodeObject): unknown;
  decodeTxBody(txBody: Uint8Array): unknown;
}

export interface SignDocBase64 {
  bodyBytes: Base64;
  authInfoBytes: Base64;
  chainId: string;
  accountNumber: string;
}

/** Canonical minimal-denom Cosmos fee coin embedded in AuthInfo. */
export interface CosmosFeeCoin {
  denom: string;
  amount: string;
}

export interface SignedTxBase64 {
  bodyBytes: Base64;
  authInfoBytes: Base64;
  signature: Base64;
}

/** Exact wallet-produced TxRaw bytes, suitable for private durable checkpointing. */
export interface SignedTxRawCheckpoint {
  signedTx: SignedTxBase64;
  txRawBytes: Uint8Array;
  /** Uppercase Cosmos transaction hash (SHA-256 of txRawBytes). */
  txHash: Hex;
  txBytesHash: Hex;
  signDocHash: Hex;
}

export interface PrivacyAccountSummary {
  address: ClairAddress;
  pubKeyHex: Hex;
  signing_message: string;
  shielded_address: ShieldedAddress;
  disclosure_pubkey_hex: Hex;
  root_signature_hash: Hex;
}

export interface DerivedPrivacyAccount {
  signing_message: string;
  shielded_address: ShieldedAddress;
  disclosure_pubkey_hex: Hex;
  root_signature_hash: Hex;
}

export interface TxSearchResult {
  height: string;
  txhash: Hex;
  code?: number;
  raw_log?: string;
  events: object[];
  tx?: object;
}

export interface BroadcastSignedTxResult {
  ok: boolean;
  txHash: Hex;
  txBytesHash: Hex;
  broadcast: {
    txhash: Hex | string;
    code: number | null;
    raw_log: string;
  };
  tx: TxSearchResult | null;
  error?: string;
}

type RequiredReservationManagerBinding =
  | { reservationManager: NoteReservationManager; reservation_manager?: NoteReservationManager | null }
  | { reservationManager?: NoteReservationManager | null; reservation_manager: NoteReservationManager };

type RequiredReservationBatchBinding =
  | { reservation: ReservationBatch; reservationBatch?: ReservationBatch | null; reservation_batch?: ReservationBatch | null }
  | { reservation?: ReservationBatch | null; reservationBatch: ReservationBatch; reservation_batch?: ReservationBatch | null }
  | { reservation?: ReservationBatch | null; reservationBatch?: ReservationBatch | null; reservation_batch: ReservationBatch };

type RequiredBatchTransferOperationIDBinding =
  | { operationId: string; operation_id?: string }
  | { operationId?: string; operation_id: string };

export type ReservationBroadcastBinding =
  | (RequiredReservationManagerBinding & RequiredReservationBatchBinding)
  | {
      reservationManager?: null;
      reservation_manager?: null;
      reservation?: null;
      reservationBatch?: null;
      reservation_batch?: null;
    };

type RelayBroadcastChainTime =
  | {
      chainNowUnix?: never;
      chain_now_unix?: never;
      getChainNowUnix: () => number | Promise<number>;
      get_chain_now_unix?: never;
    }
  | {
      chainNowUnix?: never;
      chain_now_unix?: never;
      getChainNowUnix?: never;
      get_chain_now_unix: () => number | Promise<number>;
    };

export type RelayBroadcastValidation =
  | ((
      | { relayPayload: PreparedWithdrawPayload; relay_payload?: never }
      | { relayPayload?: never; relay_payload: PreparedWithdrawPayload }
    ) & RelayBroadcastChainTime & {
      expectedChainId?: string;
      expected_chain_id?: string;
      expectedRecipient?: ClairAddress | string;
      expected_recipient?: ClairAddress | string;
      accountPrefix?: string;
      account_prefix?: string;
    })
  | {
      relayPayload?: never;
      relay_payload?: never;
      chainNowUnix?: never;
      chain_now_unix?: never;
      /** Required at broadcast time when the exact signed body contains an expiring privacy message. */
      getChainNowUnix?: () => number | Promise<number>;
      get_chain_now_unix?: () => number | Promise<number>;
      expectedChainId?: never;
      expected_chain_id?: never;
      expectedRecipient?: never;
      expected_recipient?: never;
      accountPrefix?: never;
      account_prefix?: never;
    };

export type ReservationBroadcastOptions = ReservationBroadcastBinding & RelayBroadcastValidation & {
  attempts?: number;
  intervalMs?: number;
  /**
   * Synchronous final fence invoked after all asynchronous validation and the
   * durable broadcast-attempt write, immediately before Cosmos RPC submission.
   * Throw to block submission. Returning a Promise is rejected and never awaited.
   */
  beforeBroadcast?: (identity: Readonly<{
    txHash: Hex;
    txBytesHash: Hex;
    signDocHash: Hex;
  }>) => undefined;
};

export interface ReserveResponse {
  denom: string;
  module_balance: string;
  total_deposited: string;
  total_withdrawn: string;
  expected_module_balance: string;
  invariant_holds: boolean;
}

export type Uint64CursorInput = number | bigint | string;
export type Uint64CursorValue = number | string;

export type AuthoritativeTransferPreparationTime =
  | { chainNowUnix: number; chain_now_unix?: number }
  | { chain_now_unix: number; chainNowUnix?: number };

export interface PrivacyEventsQuery {
  afterHeight?: Uint64CursorInput;
  after_height?: Uint64CursorInput;
  afterSequence?: Uint64CursorInput;
  after_sequence?: Uint64CursorInput;
  page?: number;
  limit?: number;
  eventTypes?: string[];
  event_types?: string[];
}

export interface PrivacyScanOptions extends PrivacyEventsQuery {
  after?: PrivacyScanCursorInput;
  outputLimit?: number;
  output_limit?: number;
  eventLimit?: number;
  event_limit?: number;
  maxEncodedBytes?: Uint64CursorInput;
  max_encoded_bytes?: Uint64CursorInput;
  maxPages?: number;
  max_pages?: number;
  /** Durable typed-page state returned by nextPrivacyScanOptions. */
  validationStateSnapshot?: PrivacyScanValidationStateSnapshotV2;
  validation_state_snapshot?: PrivacyScanValidationStateSnapshotV2;
  scanSource?: "privacy_scan" | "scan_events" | "privacy_events" | string;
  scan_source?: "privacy_scan" | "scan_events" | "privacy_events" | string;
  /** Fail closed instead of falling back when privacy-scan-v2 is unavailable. */
  strictPrivacyScan?: boolean;
  strict_privacy_scan?: boolean;
}

/**
 * Scan options accepted by wallet balance and spend-selection APIs. These
 * surfaces always consume the complete typed projection and fail closed.
 */
export type TypedWalletScanOptions = Omit<
  PrivacyScanOptions,
  | "afterHeight"
  | "after_height"
  | "afterSequence"
  | "after_sequence"
  | "eventTypes"
  | "event_types"
  | "scanSource"
  | "scan_source"
  | "strictPrivacyScan"
  | "strict_privacy_scan"
> & {
  afterHeight?: never;
  after_height?: never;
  afterSequence?: never;
  after_sequence?: never;
  eventTypes?: readonly [];
  event_types?: readonly [];
  scanSource?: "privacy_scan";
  scan_source?: "privacy_scan";
  strictPrivacyScan?: true;
  strict_privacy_scan?: true;
};

export interface PrivacyScanCursorInput {
  height?: Uint64CursorInput;
  globalSequence?: Uint64CursorInput;
  global_sequence?: Uint64CursorInput;
  outputIndex?: number;
  output_index?: number;
}

export interface TypedPrivacyScanQuery {
  after?: PrivacyScanCursorInput;
  outputLimit?: number;
  output_limit?: number;
  eventLimit?: number;
  event_limit?: number;
  maxEncodedBytes?: Uint64CursorInput;
  max_encoded_bytes?: Uint64CursorInput;
  eventTypes?: string[];
  event_types?: string[];
  /** Retain the same mutable state while fetching consecutive cursor pages. */
  validationState?: PrivacyScanValidationStateV2;
  validation_state?: PrivacyScanValidationStateV2;
}

export interface CommitmentPathsAtRootQuery {
  commitmentHexes?: readonly Hex[];
  commitment_hexes?: readonly Hex[];
  rootHex?: Hex;
  root_hex?: Hex;
  snapshotHeight?: Uint64CursorInput;
  snapshot_height?: Uint64CursorInput;
}

export type RelayChainTimeInput =
  | { chainNowUnix: number; chain_now_unix?: number }
  | { chainNowUnix?: number; chain_now_unix: number };

type CosmosRelayWithdrawRelayOptions = Omit<RelayWithdrawRelayOptions, "chainNowUnix"> & (
  | {
      chainNowUnix: number;
      /** @deprecated Use chainNowUnix with the latest chain block time. */
      nowUnix?: number;
    }
  | {
      chainNowUnix?: number;
      /** @deprecated Use chainNowUnix with the latest chain block time. */
      nowUnix: number;
    }
);

export interface PrivacyEventsCursor {
  source?: "privacy_scan" | "scan_events" | "privacy_events" | string;
  after?: { height?: Uint64CursorValue; globalSequence?: Uint64CursorValue; global_sequence?: Uint64CursorValue; outputIndex?: number; output_index?: number };
  next_cursor?: { height?: Uint64CursorValue; globalSequence?: Uint64CursorValue; global_sequence?: Uint64CursorValue; outputIndex?: number; output_index?: number };
  /** Validated state persisted with a partial privacy_scan cursor. */
  validation_state?: PrivacyScanValidationStateSnapshotV2;
  output_limit?: number;
  event_limit?: number;
  max_encoded_bytes?: Uint64CursorInput;
  latest_output_index?: number;
  after_height?: Uint64CursorValue;
  after_sequence?: Uint64CursorValue;
  page?: number;
  limit?: number;
  event_types: string[];
  has_more: boolean;
  latest_height: Uint64CursorValue;
  latest_sequence?: Uint64CursorValue;
  latest_tx_hash?: Hex | "";
  next_height?: Uint64CursorValue;
  next_sequence?: Uint64CursorValue;
  next_page?: number;
  pages_scanned?: number;
  completed?: boolean;
  scan_format_version?: number;
  view_tag_version?: number;
}

export interface PrivacyScanResumeOptions {
  after?: { height?: Uint64CursorValue; globalSequence?: Uint64CursorValue; global_sequence?: Uint64CursorValue; outputIndex?: number; output_index?: number };
  afterHeight?: Uint64CursorValue;
  afterSequence?: Uint64CursorValue;
  page?: number;
  limit: number;
  eventTypes: string[];
  outputLimit?: number;
  eventLimit?: number | Uint64CursorValue;
  maxEncodedBytes?: Uint64CursorValue;
  scanSource?: "privacy_scan" | "scan_events" | "privacy_events" | string;
  maxPages?: number;
  validationStateSnapshot?: PrivacyScanValidationStateSnapshotV2;
  includeFoundNotes?: boolean;
  hasMore: boolean;
  completed: boolean;
}

export interface WalletScanInput extends TypedWalletScanOptions {
  rootSeed: Uint8Array;
  includeFoundNotes?: boolean;
}

export interface ClairveilClientOptions {
  /** Required for Cosmos transaction/balance APIs; optional for adapter-backed EVM state queries. */
  rpc?: string;
  rest?: string;
  restEndpoints?: string[];
  chainId: string;
  accountPrefix?: string;
  bech32Prefix?: string;
  shieldedPrefix?: string;
  defaultDenom?: string;
  assetDenom?: string;
  registry?: object;
  queryTimeoutMs?: number;
  fetchTimeoutMs?: number;
  queryRetry?: QueryRetryOptions | false;
  nullifierFailover?: boolean;
  /** Allow Merkle witness and exact-snapshot queries to fail over across REST endpoints. */
  merklePathFailover?: boolean;
  /** Replaces Clairveil REST privacy reads while preserving SDK validation/planning. */
  privacyStateAdapter?: PrivacyStateAdapter;
  expectedCircuitIdentity?: CircuitSetIdentityV1;
  /** Explicit downstream gate required until this integration passes its own localnet matrix. */
  enableExperimentalBatchTransfer?: boolean;
  enable_experimental_batch_transfer?: boolean;
}

export interface QueryRetryOptions {
  retries?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
  jitter?: boolean;
  retryStatuses?: number[];
}

export interface ReservationReconciliationWarning {
  code: "reservation_heartbeat_failed_after_proof_ready";
  message: string;
  cause?: string;
}

export interface ReservationReconciliationState {
  reservationReconciliationRequired?: true;
  reservationReconciliationWarning?: ReservationReconciliationWarning;
}

export interface PreparedDeposit {
  status: "ready";
  signDoc: SignDocBase64;
  message: MsgDepositMessage;
  material: DepositMaterial;
  privacyAccount: PrivacyAccountSummary;
}

export interface ConfirmedDeposit {
  status: "confirmed";
  txHash: Hex;
  tx: TxSearchResult;
  event: object;
  commitment: Hex;
  encryptedNote: Hex;
}

export interface PreparedTransferSummary {
  planAction: "final_transfer" | "self_merge" | string;
  isFinal: boolean;
  amount: CoinString;
  recipient: ShieldedAddress;
  finalAmount: CoinString;
  finalRecipient: ShieldedAddress;
  selectedInputTotal: string;
  expiresAtUnix: number;
  chainNowUnix: number;
  reservation?: ReservationBatch | null;
}

export interface PreparedTransfer extends ReservationReconciliationState {
  status: string;
  plan: TransferPlan;
  scan: ScanResult;
  signDoc?: SignDocBase64;
  /** Present when executionBuilder produced a non-Cosmos execution artifact. */
  execution?: PreparedTransferExecution;
  payload?: PreparedTransferPayload;
  proof?: PreparedTransferProof;
  message?: TransferMessage;
  reservation?: ReservationBatch | null;
  prepared?: PreparedTransferSummary;
  privacyAccount: PrivacyAccountSummary;
}

export interface PreparedTransferBatchSummary {
  planAction: "batch_transfer";
  payments: Array<{
    itemId: string;
    amount: CoinString;
    recipient: ShieldedAddress;
    privacyPolicy: string;
    disclosureMode: string;
  }>;
  amounts: CoinString[];
  /** Present only when every payment has the same recipient. */
  recipient?: ShieldedAddress;
  outputMode: "compact" | "exact32";
  selectedInputTotal?: string;
  inputCount?: number;
  outputCount?: number;
  reservation?: ReservationBatch | null;
}

export interface PreparedTransferBatch extends ReservationReconciliationState {
  status: string;
  plan: TransferBatchPlan;
  scan: ScanResult;
  signDoc?: SignDocBase64;
  /** Present when the caller supplied executionBuilder instead of a Cosmos sign-doc flow. */
  execution?: PreparedBatchTransferExecution;
  payload?: PreparedBatchTransferPayload;
  proof?: PreparedBatchTransferProof;
  message?: MsgBatchTransferMessage;
  operationEvidence?: BatchTransferOperationEvidence;
  operationEvidenceHash?: Hex;
  reservation?: ReservationBatch | null;
  prepared?: PreparedTransferBatchSummary;
  privacyAccount: PrivacyAccountSummary;
}

interface PreparedWithdrawBase extends ReservationReconciliationState {
  plan: WithdrawPlan;
  scan: ScanResult;
  reservation?: ReservationBatch | null;
  privacyAccount: PrivacyAccountSummary;
}

export interface PreparedWithdrawReady extends PreparedWithdrawBase {
  status: "ready";
  signDoc: SignDocBase64;
  proverPayload: PreparedWithdrawProverPayload;
  proof: PreparedWithdrawProof;
  payload: PreparedWithdrawPayload;
  message: WithdrawMessage;
  selectedNote: FoundNote;
}

export interface PreparedWithdrawNotReady extends PreparedWithdrawBase {
  status: Exclude<WithdrawPlan["status"], "withdraw_ready">;
  signDoc?: never;
  proverPayload?: never;
  proof?: never;
  payload?: never;
  message?: never;
  selectedNote?: never;
}

export type PreparedWithdraw = PreparedWithdrawReady | PreparedWithdrawNotReady;

export interface PreparedWithdrawExecutionReady extends PreparedWithdrawBase {
  status: "ready";
  signDoc?: never;
  execution: PreparedWithdrawExecutionArtifact;
  proverPayload: PreparedWithdrawProverPayload;
  proof: PreparedWithdrawProof;
  payload: PreparedWithdrawPayload;
  message: WithdrawMessage;
  selectedNote: FoundNote;
}

export type PreparedWithdrawWithExecution = PreparedWithdrawExecutionReady | PreparedWithdrawNotReady;

export interface PreparedRelayWithdraw extends ReservationReconciliationState {
  status: string;
  plan: WithdrawPlan;
  scan: ScanResult;
  proverPayload?: PreparedWithdrawProverPayload;
  proof?: PreparedWithdrawProof;
  payload?: PreparedWithdrawPayload;
  selectedNote?: FoundNote;
  /** Present when executionBuilder atomically bound a downstream execution artifact before ProofReady. */
  execution?: PreparedWithdrawExecutionArtifact;
  reservation?: ReservationBatch | null;
  privacyAccount: PrivacyAccountSummary;
}

export interface PreparedRelayWithdrawSignDoc {
  status: "ready";
  relayer: ClairAddress | string;
  payload: PreparedWithdrawPayload;
  message: WithdrawMessage;
  signDoc: SignDocBase64;
}

/** A canonical 164-byte gnark BN254 Groth16 frame, validated before MsgDeposit encoding. */
export type DepositProofInput =
  | { proof: Uint8Array | Hex; proofHex?: Hex; proof_hex?: Hex }
  | { proof?: Uint8Array | Hex; proofHex: Hex; proof_hex?: Hex }
  | { proof?: Uint8Array | Hex; proofHex?: Hex; proof_hex: Hex };

/** Required to authenticate and decrypt the supplied deposit envelope before signing. */
type DepositRootSeedBinding =
  | { rootSeed: Uint8Array; root_seed?: Uint8Array }
  | { rootSeed?: Uint8Array; root_seed: Uint8Array };

export type ValidateDepositMaterialInput = {
  creator: ClairAddress;
  amount: CoinString;
  memo?: string;
  assetDenom?: string;
  denom?: string;
  shieldedAddress?: ShieldedAddress;
  depositMaterial?: object;
  deposit_material?: object;
  material?: DepositMaterial;
} & DepositRootSeedBinding;

export interface ValidatedDepositMaterial {
  material: DepositMaterial;
  message: {
    creator: ClairAddress | string;
    amount: CoinString;
    noteCommitment: Uint8Array;
    encryptedNote: Uint8Array;
  };
}

export type BuildDepositMessageInput = ValidateDepositMaterialInput & DepositProofInput;

export type PrivacyPreparationResult<Input, Result> = Input extends { privacyIdentity: WalletPrivacyIdentity }
  ? Result extends unknown ? Omit<Result, 'privacyAccount'> & { privacyAccount: PublicPrivacyIdentity } : never
  : Result;

export type WalletPreparationContext =
  | { wallet?: WalletAdapterLike; material?: PrivacyMaterial; privacyIdentity?: never; chainActor?: never }
  | { wallet?: never; material?: never; privacyIdentity: WalletPrivacyIdentity; chainActor: ChainActor };
export type WalletScanContext =
  | { wallet?: WalletAdapterLike; material?: PrivacyMaterial; privacyIdentity?: never; chainActor?: never }
  | { wallet?: never; material?: never; privacyIdentity: WalletPrivacyIdentity; chainActor?: ChainActor };

export type PrepareDepositInput = WalletPreparationContext & {
  depositMaterial?: object;
  deposit_material?: object;
  amount: CoinString;
  memo?: string;
  gasLimit?: number;
  gas_limit?: number;
  /** Exact profile/caller-selected fee coins embedded in the sign doc. */
  feeAmount?: readonly CosmosFeeCoin[];
  fee_amount?: readonly CosmosFeeCoin[];
  denom?: string;
  assetDenom?: string;
} & DepositProofInput;

export type ConfirmDepositInput = {
  txHash?: Hex;
  tx_hash?: Hex;
  prepared?: PreparedDeposit | object;
  material?: DepositMaterial;
  depositMaterial?: object;
  deposit_material?: object;
  message?: MsgDepositMessage | object;
  expectedCommitment?: Hex;
  expected_commitment?: Hex;
  expectedEncryptedNote?: Hex;
  expected_encrypted_note?: Hex;
  waitOptions?: { attempts?: number; intervalMs?: number };
  attempts?: number;
  intervalMs?: number;
};

export function createClairveilRegistry(
  extraTypes?: ReadonlyArray<readonly [string, ClairveilRegistryGeneratedType]>
): ClairveilRegistry;
export function normalizeRpcEndpoint(rpc: string): string;
export function normalizeRestEndpoint(rest: string): string;
export function buildRootSigningMessage(address: ClairAddress, pubKeyHex: Hex): string;
export function cosmosAddressFromPubKey(pubKeyHex: Hex, prefix?: string): ClairAddress;
export function verifySignerPubKey(address: ClairAddress, pubKeyHex: Hex, prefix?: string): {
  address: ClairAddress;
  expectedAddress: ClairAddress;
  matches: boolean;
};
export function assertSignerPubKey(address: ClairAddress, pubKeyHex: Hex, prefix?: string): {
  address: ClairAddress;
  expectedAddress: ClairAddress;
  matches: true;
};
export function eventAttribute(event: object, key: string): string;
export function isAuditableTransfer(event: object): boolean;
/** Reject a user disclosure policy or mode that the active chain does not support. */
export function assertTransferDisclosureCapabilities(
  disclosureConfig: ValidatedDisclosureConfigV1,
  options?: { userPrivacyPolicy?: string | number; userDisclosureMode?: string | number }
): { policy: string; mode: string };
export function cosmosSignDocBindingHash(signDoc: Pick<SignDocBase64, "bodyBytes" | "authInfoBytes">): Hex;

export type DirectOperationEvidenceHashes = {
  /** Optional assertion; the SDK always derives this hash from `recipient`. */
  expectedRecipientHash?: string;
  /** Snake-case alias for `expectedRecipientHash`. */
  expected_recipient_hash?: string;
  /** Optional assertion; the SDK always derives this hash from `amount`. */
  expectedAmountHash?: string;
  /** Snake-case alias for `expectedAmountHash`. */
  expected_amount_hash?: string;
};

type BatchRecipientHashEvidence =
  | {
      expectedRecipientHash: string;
      expected_recipient_hash?: string;
      expectedRecipientHashes?: readonly string[];
      expected_recipient_hashes?: readonly string[];
    }
  | {
      expected_recipient_hash: string;
      expectedRecipientHash?: string;
      expectedRecipientHashes?: readonly string[];
      expected_recipient_hashes?: readonly string[];
    }
  | {
      expectedRecipientHashes: readonly string[];
      expectedRecipientHash?: string;
      expected_recipient_hash?: string;
      expected_recipient_hashes?: readonly string[];
    }
  | {
      expected_recipient_hashes: readonly string[];
      expectedRecipientHash?: string;
      expected_recipient_hash?: string;
      expectedRecipientHashes?: readonly string[];
    };

type BatchAmountHashEvidence =
  | {
      expectedAmountHashes: readonly string[];
      expected_amount_hashes?: readonly string[];
    }
  | {
      expected_amount_hashes: readonly string[];
      expectedAmountHashes?: readonly string[];
    };

export type BatchOperationEvidenceHashes =
  | {
      expectedRecipientHash?: never;
      expected_recipient_hash?: never;
      expectedRecipientHashes?: never;
      expected_recipient_hashes?: never;
      expectedAmountHashes?: never;
      expected_amount_hashes?: never;
    }
  | (BatchRecipientHashEvidence & BatchAmountHashEvidence);

export const batchTransferOperationEvidenceVersion: "batch-transfer-operation-evidence-v1";

export interface TransferBatchPaymentInput {
  itemId?: string;
  item_id?: string;
  amount: CoinString;
  recipient?: ShieldedAddress;
  recipientAddress?: ShieldedAddress;
  recipient_address?: ShieldedAddress;
  privacyPolicy?: string | number;
  privacy_policy?: string | number;
  userPrivacyPolicy?: string | number;
  user_privacy_policy?: string | number;
  disclosureMode?: string | number;
  disclosure_mode?: string | number;
  userDisclosureMode?: string | number;
  user_disclosure_mode?: string | number;
  disclosurePubKeyHex?: Hex;
  disclosure_pubkey_hex?: Hex;
  userDisclosureTargetPubKeyHex?: Hex;
  user_disclosure_target_pubkey_hex?: Hex;
  expectedRecipientHash?: Hex;
  expected_recipient_hash?: Hex;
  expectedAmountHash?: Hex;
  expected_amount_hash?: Hex;
  expectedOutputCommitment?: Hex;
  expected_output_commitment?: Hex;
  expectedUserDisclosureDigest?: Hex;
  expected_user_disclosure_digest?: Hex;
  expectedAuditDisclosureDigest?: Hex;
  expected_audit_disclosure_digest?: Hex;
  expectedSelfViewDisclosureDigest?: Hex;
  expected_self_view_disclosure_digest?: Hex;
  expectedDisclosureDigest?: Hex;
  expected_disclosure_digest?: Hex;
  memo?: string;
}

export interface BatchTransferExpectedOutputEvidence {
  operation_id: string;
  item_id: string;
  batch_item_index: number;
  role: "payment";
  expected_output_commitment: Hex;
  expected_user_disclosure_digest: Hex | "";
  expected_audit_disclosure_digest: Hex;
  expected_self_view_disclosure_digest: Hex | "";
  expected_recipient_hash: Hex;
  expected_amount: string;
  expected_amount_hash: Hex;
  expected_denom: string;
  asset_id_hex: Hex;
  user_privacy_policy: number;
  user_disclosure_mode: number;
  audit_key_id: string;
  audit_key_epoch: string;
}

export interface BatchTransferOperationEvidence {
  version: typeof batchTransferOperationEvidenceVersion;
  operation_id: string;
  circuit_set_id: "privacy-note-v1";
  payload_hash: Hex;
  proof_payload_hash: Hex;
  proof_hash: Hex;
  input_nullifier_hexes: readonly Hex[];
  expected_outputs: readonly BatchTransferExpectedOutputEvidence[];
}

type PrepareTransferBatchPaymentShape =
  | {
      payments: readonly TransferBatchPaymentInput[];
      amounts?: never;
      recipient?: never;
    }
  | {
      payments?: never;
      amounts: CoinString[];
      recipient: ShieldedAddress;
    };

export type PreparedBatchTransferPayloadCheckpoint = (
  payload: PreparedBatchTransferPayload,
  context: { operationId: string; reservation: ReservationBatch | null }
) => Promise<void> | void;

export type PreparedBatchTransferProofCheckpoint = (
  proof: PreparedBatchTransferProof,
  context: {
    payload: PreparedBatchTransferPayload;
    operationId: string;
    reservation: ReservationBatch | null;
  }
) => Promise<void> | void;

/**
 * An execution artifact built from the one-proof batch after the proof and
 * operation evidence are fixed, but before reservations transition to
 * ProofReady. The binding hash is persisted with every reserved input.
 */
export type PreparedExecutionTransport = "evm" | "external";

export type PreparedExecutionArtifact = {
  txBytesHash: string;
  tx_bytes_hash?: string;
  /** Use evm for strict network transaction/receipt/event reconciliation. */
  executionTransport: PreparedExecutionTransport;
  execution_transport?: PreparedExecutionTransport;
  transaction?: object;
  authorization?: object;
  authorizationTypedData?: object;
};

export type PreparedTransferExecution = PreparedExecutionArtifact & {
  message?: TransferMessage;
};

export type PreparedWithdrawExecutionArtifact = PreparedExecutionArtifact & {
  message?: WithdrawMessage;
};

export type PreparedBatchTransferExecution = PreparedExecutionArtifact;

export type PreparedTransferExecutionBuilder = (input: {
  payload: PreparedTransferPayload;
  proof: PreparedTransferProof;
  message: TransferMessage;
  plan: TransferPlan;
  isFinal: boolean;
  reservation: ReservationBatch | null;
}) => PreparedTransferExecution | Promise<PreparedTransferExecution>;

export type PreparedWithdrawExecutionBuilder = (input: {
  payload: PreparedWithdrawPayload;
  proof: PreparedWithdrawProof;
  proverPayload: PreparedWithdrawProverPayload;
  selectedNote: FoundNote;
  message: WithdrawMessage;
  plan: WithdrawPlan;
  reservation: ReservationBatch | null;
}) => PreparedWithdrawExecutionArtifact | Promise<PreparedWithdrawExecutionArtifact>;

export type PreparedRelayWithdrawExecutionBuilder = (input: {
  payload: PreparedWithdrawPayload;
  proof: PreparedWithdrawProof;
  proverPayload: PreparedWithdrawProverPayload;
  selectedNote: FoundNote;
  plan: WithdrawPlan;
  reservation: ReservationBatch | null;
}) => PreparedWithdrawExecutionArtifact | Promise<PreparedWithdrawExecutionArtifact>;

export type PreparedBatchTransferExecutionBuilder = (input: {
  payload: PreparedBatchTransferPayload;
  proof: PreparedBatchTransferProof;
  message: MsgBatchTransferMessage;
  operationEvidence: BatchTransferOperationEvidence;
  operationEvidenceHash: Hex;
  reservation: ReservationBatch | null;
}) => PreparedBatchTransferExecution | Promise<PreparedBatchTransferExecution>;

type RequiredPreparedBatchTransferPayloadCheckpoint =
  | {
      onPreparedPayload: PreparedBatchTransferPayloadCheckpoint;
      on_prepared_payload?: PreparedBatchTransferPayloadCheckpoint;
    }
  | {
      onPreparedPayload?: PreparedBatchTransferPayloadCheckpoint;
      on_prepared_payload: PreparedBatchTransferPayloadCheckpoint;
    };

type RequiredPreparedBatchTransferProofCheckpoint =
  | {
      onPreparedProof: PreparedBatchTransferProofCheckpoint;
      on_prepared_proof?: PreparedBatchTransferProofCheckpoint;
    }
  | {
      onPreparedProof?: PreparedBatchTransferProofCheckpoint;
      on_prepared_proof: PreparedBatchTransferProofCheckpoint;
    };

export type PrepareTransferBatchInput = {
  wallet?: WalletAdapterLike;
  material?: PrivacyMaterial;
  proverAdapter: BatchTransferProverAdapter;
  signal?: AbortSignal;
  outputMode?: "compact" | "exact32" | "exact-32";
  output_mode?: "compact" | "exact32" | "exact-32";
  gasLimit?: number;
  gas_limit?: number;
  /** Exact profile/caller-selected fee coins, snapshotted before scan/proving. */
  feeAmount?: readonly CosmosFeeCoin[];
  fee_amount?: readonly CosmosFeeCoin[];
  expiresAtUnix?: number;
  expires_at_unix?: number;
  chainNowUnix?: number;
  chain_now_unix?: number;
  rootHex?: Hex;
  root_hex?: Hex;
  snapshotHeight?: Uint64CursorInput;
  snapshot_height?: Uint64CursorInput;
  /** Advanced deterministic selection; every listed typed-scan note is consumed in this order. */
  inputCommitmentHexes?: readonly Hex[];
  input_commitment_hexes?: readonly Hex[];
  disableSelfViewDisclosure?: boolean;
  disable_self_view_disclosure?: boolean;
  selfViewDisclosureTargetPubKeyHex?: Hex;
  self_view_disclosure_target_pubkey?: Hex;
  userPrivacyPolicy?: string | number;
  userDisclosureMode?: string | number;
  userDisclosureTargetPubKeyHex?: Hex;
  auditDisclosureTargetPubKeyHex?: Hex;
  audit_disclosure_target_pubkey_hex?: Hex;
  denom?: string;
  page?: number;
  limit?: number;
  maxPages?: number;
  max_pages?: number;
  scan?: TypedWalletScanOptions;
  scanSource?: "privacy_scan";
  scan_source?: "privacy_scan";
} & TypedWalletScanOptions &
  PrepareTransferBatchPaymentShape &
  BatchOperationEvidenceHashes &
  RequiredReservationManagerBinding &
  RequiredPreparedBatchTransferPayloadCheckpoint &
  RequiredPreparedBatchTransferProofCheckpoint;

/**
 * Restores the non-proving half of a checkpointed one-proof batch transfer.
 * Supply the exact original payment rows so the SDK can bind the recovered
 * payload/proof to per-item operation evidence before it makes the
 * reservation broadcastable. The manager must support authoritative
 * getReservations/lookupKeyForNote reads; the finalizer verifies the stored
 * operation, current lease owner/token, and exact payload-nullifier lookup-key
 * set before any Proving -> ProofReady transition.
 */
type FinalizePreparedBatchTransferExecutionInput =
  | {
      executionBuilder: PreparedBatchTransferExecutionBuilder;
      pubKeyHex?: Hex;
      gasLimit?: number | bigint;
      gas_limit?: number | bigint;
    }
  | ({
      executionBuilder?: never;
      pubKeyHex: Hex;
    } & (
      | { gasLimit: number | bigint; gas_limit?: number | bigint }
      | { gasLimit?: number | bigint; gas_limit: number | bigint }
    ));

export type FinalizePreparedBatchTransferInput = {
  payload: PreparedBatchTransferPayload;
  proof: PreparedBatchTransferProof;
  signer: ClairAddress | string;
  /** Exact profile/caller-selected fee coins embedded in the recovered ProofReady sign doc. */
  feeAmount?: readonly CosmosFeeCoin[];
  fee_amount?: readonly CosmosFeeCoin[];
  memo?: string;
  userPrivacyPolicy?: string | number;
  userDisclosureMode?: string | number;
  userDisclosureTargetPubKeyHex?: Hex;
  denom?: string;
  chainNowUnix?: number;
  chain_now_unix?: number;
} & FinalizePreparedBatchTransferExecutionInput &
  PrepareTransferBatchPaymentShape &
  BatchOperationEvidenceHashes &
  RequiredBatchTransferOperationIDBinding &
  RequiredReservationManagerBinding &
  RequiredReservationBatchBinding;

interface FinalizedPreparedBatchTransferBase {
  payload: PreparedBatchTransferPayload;
  proof: PreparedBatchTransferProof & { proof_bytes: Uint8Array };
  message: MsgBatchTransferMessage;
  effects: { root_hex: Hex; nullifier_hexes: Hex[]; output_commitment_hexes: Hex[] };
  operationEvidence: BatchTransferOperationEvidence;
  operationEvidenceHash: Hex;
  reservation: ReservationBatch;
}

export type FinalizedPreparedBatchTransfer = FinalizedPreparedBatchTransferBase & (
  | { signDoc: SignDocBase64; execution?: never }
  | { signDoc?: never; execution: PreparedBatchTransferExecution }
);

export class ClairveilJS {
  constructor(options: ClairveilClientOptions);
  connect(): Promise<object>;
  disconnect(): Promise<void>;
  restEndpoints: string[];
  activeRestEndpoint: string;
  privacyStateAdapter: Readonly<PrivacyStateAdapter> | null;
  restUrl(path: string, endpoint?: string): string;
  fetchJson<T = object>(pathOrUrl: string, options?: {
    failover?: boolean;
    retry?: QueryRetryOptions | false;
    method?: string;
    body?: BodyInit | null;
    headers?: Record<string, string>;
    endpoint?: string;
    updateActiveEndpoint?: boolean;
  }): Promise<T>;
  fetchNullifierJson<T = object>(path: string, options?: {
    retry?: QueryRetryOptions | false;
    method?: string;
    body?: BodyInit | null;
    headers?: Record<string, string>;
  }): Promise<T>;
  fetchMerklePathJson<T = object>(path: string, options?: {
    retry?: QueryRetryOptions | false;
    method?: string;
    body?: BodyInit | null;
    headers?: Record<string, string>;
  }): Promise<T>;
  getAccountInfo(address: ClairAddress): Promise<{ accountNumber: bigint; sequence: bigint }>;
  getBalances(address: ClairAddress): Promise<object>;
  getTx(txHash: Hex): Promise<TxSearchResult | null>;
  waitForTx(txHash: Hex, options?: { attempts?: number; intervalMs?: number }): Promise<TxSearchResult | null>;
  fetchPrivacyEvents(options?: PrivacyEventsQuery): Promise<object & { events?: object[] }>;
  fetchPrivacyScan(options?: TypedPrivacyScanQuery): Promise<object>;
  queryPrivacyScan(options?: TypedPrivacyScanQuery): Promise<ValidatedPrivacyScanPageV2>;
  fetchTreeState(): Promise<object>;
  fetchCommitmentInfo(commitmentHex: Hex): Promise<object>;
  fetchAuditConfig(): Promise<object>;
  fetchDisclosureConfig(): Promise<object>;
  queryAuditConfig(): Promise<import("../privacy/network-config.js").ValidatedAuditConfigV1>;
  queryDisclosureConfig(): Promise<import("../privacy/network-config.js").ValidatedDisclosureConfigV1>;
  fetchCircuitConfig(options?: { expectedCircuitIdentity?: ValidatedCircuitConfigV1["circuit_set_identity"] }): Promise<ValidatedCircuitConfigV1>;
  assertCircuitConfig(options?: { expectedCircuitIdentity?: ValidatedCircuitConfigV1["circuit_set_identity"] }): Promise<ValidatedCircuitConfigV1>;
  fetchReserve(denom: string): Promise<ReserveResponse>;
  queryReserve(denom: string): Promise<import("../privacy/network-config.js").ValidatedReserveResponseV1>;
  fetchAssetByDenom(denom: string): Promise<object>;
  fetchAssetByID(assetIdHex: Hex): Promise<object>;
  queryAssetByDenom(denom: string): Promise<NormalizedAssetRegistryQueryResponseV1>;
  queryAssetByID(assetIdHex: Hex): Promise<NormalizedAssetRegistryQueryResponseV1>;
  resolveAsset(denom: string): Promise<NormalizedAssetRegistryEntryV1>;
  resolveAssetByDenom(denom: string): Promise<NormalizedAssetRegistryEntryV1>;
  resolveAssetByID(assetIdHex: Hex): Promise<NormalizedAssetRegistryEntryV1>;
  assertProtocolPreflight(denom: string): Promise<{ circuit_config: ValidatedCircuitConfigV1; asset: NormalizedAssetRegistryEntryV1 }>;
  assertTransferProtocolConfig(denom: string): Promise<{
    circuit_config: ValidatedCircuitConfigV1;
    asset: NormalizedAssetRegistryEntryV1;
    audit_config: import("../privacy/network-config.js").ValidatedAuditConfigV1;
    disclosure_config: import("../privacy/network-config.js").ValidatedDisclosureConfigV1;
  }>;
  fetchCommitmentPathsAtRoot(options: CommitmentPathsAtRootQuery): Promise<object>;
  queryCommitmentPathsAtRoot(options: CommitmentPathsAtRootQuery): Promise<VerifiedCommitmentPathSnapshot>;
  createCommitmentPathSnapshotProvider(options: CommitmentPathsAtRootQuery): Promise<{
    lookupMerklePath(commitmentHex: Hex): Promise<object>;
  }>;
  lookupMerklePath(commitmentHex: Hex): Promise<object>;
  checkNullifier(nullifierHex: Hex): Promise<{ nullifier: string; used: boolean }>;
  checkNullifiers(nullifierHexes: readonly Hex[]): Promise<Map<Hex, boolean>>;
  deriveWalletPrivacyMaterial(wallet: WalletAdapterLike): Promise<PrivacyMaterial>;
  scanNotes(input: WalletScanInput): Promise<ScanResult & {
    scanCursor: PrivacyEventsCursor;
    nextScanOptions: PrivacyScanResumeOptions;
  }>;
  fetchScanEvents(options?: PrivacyEventsQuery): Promise<object & {
    events?: object[];
    next_height?: Uint64CursorValue;
    next_sequence?: Uint64CursorValue;
    has_more?: boolean;
    scan_format_version?: number;
    view_tag_version?: number;
  }>;
  fetchAuditableTransfers(options?: PrivacyEventsQuery): Promise<object & { events: object[] }>;
  fetchAuditableBatchTransfers(options?: TypedPrivacyScanQuery): Promise<ValidatedPrivacyScanPageV2>;
  findPrivacyEventByTxHash(txHash: Hex, options?: PrivacyScanOptions): Promise<object>;
  derivePrivacyAccount(input: {
    address: ClairAddress;
    pubKeyHex?: Hex;
    pub_key_hex?: Hex;
    signatureBase64?: Base64;
    signature_base64?: Base64;
  }): DerivedPrivacyAccount;
  buildDepositMaterial(input: {
    creator?: ClairAddress | string;
    shieldedAddress?: ShieldedAddress;
    amount?: CoinString;
    memo?: string;
    assetDenom?: string;
    denom?: string;
    shieldedPrefix?: string;
  } & DepositRootSeedBinding): DepositMaterial;
  /** Validate every proof-independent Cosmos deposit binding before proving or signing. */
  validateDepositMaterial(input: ValidateDepositMaterialInput): ValidatedDepositMaterial;
  scanWalletNotes(input: TypedWalletScanOptions & WalletScanContext & {
    limit?: number;
    maxPages?: number;
    noteStore?: MemoryNoteStore;
    includeFoundNotes?: boolean;
  }): Promise<ScanResult & {
    privacyAccount: object;
    scanCursor: PrivacyEventsCursor;
    nextScanOptions: PrivacyScanResumeOptions;
  }>;
  planWalletTransfer(input: {
    wallet?: WalletAdapterLike;
    material?: PrivacyMaterial;
    amount: CoinString;
    denom?: string;
    limit?: number;
    maxPages?: number;
    scan?: TypedWalletScanOptions;
    scanSource?: "privacy_scan";
    scan_source?: "privacy_scan";
  }): Promise<{ plan: TransferPlan; scan: ScanResult }>;
  planWalletWithdraw(input: {
    wallet?: WalletAdapterLike;
    material?: PrivacyMaterial;
    amount: CoinString;
    denom?: string;
    limit?: number;
    maxPages?: number;
    scan?: TypedWalletScanOptions;
    scanSource?: "privacy_scan";
    scan_source?: "privacy_scan";
  }): Promise<{ plan: WithdrawPlan; scan: ScanResult }>;
  buildDepositMessage(input: BuildDepositMessageInput): object;
  prepareDeposit<Input extends PrepareDepositInput>(input: Input): Promise<PrivacyPreparationResult<Input, PreparedDeposit>>;
  confirmDeposit(input: ConfirmDepositInput): Promise<ConfirmedDeposit>;
  prepareTransfer<Input extends WalletPreparationContext & {
    amount: CoinString;
    recipient: ShieldedAddress;
    proverAdapter: ProverAdapter;
    signal?: AbortSignal;
    allowPlanStep?: boolean;
    gasLimit?: number;
    gas_limit?: number;
    userPrivacyPolicy?: string | number;
    userDisclosureMode?: string | number;
    userDisclosureTargetPubKeyHex?: Hex;
    /** Sender self-view is enabled by default; set true only for an explicit opt-out. */
    disableSelfViewDisclosure?: boolean;
    disable_self_view_disclosure?: boolean;
    selfViewDisclosureTargetPubKeyHex?: Hex;
    self_view_disclosure_target_pubkey?: Hex;
    /** Optional safety assertion; if set, it must equal the active chain audit master key. */
    auditDisclosureTargetPubKeyHex?: Hex;
    /** Optional explicit expiry; defaults to authoritative chain time + 1800 seconds. */
    expiresAtUnix?: number;
    expires_at_unix?: number;
    /** Authoritative chain time is required before an executable transfer proof is prepared. */
    chainNowUnix?: number;
    chain_now_unix?: number;
    denom?: string;
    page?: number;
    limit?: number;
    maxPages?: number;
    max_pages?: number;
    scan?: TypedWalletScanOptions;
    scanSource?: "privacy_scan";
    scan_source?: "privacy_scan";
    /** Exact profile/caller-selected fee coins, snapshotted before proof preparation. */
    feeAmount?: readonly CosmosFeeCoin[];
    fee_amount?: readonly CosmosFeeCoin[];
    reservationManager?: NoteReservationManager | null;
    reservation_manager?: NoteReservationManager | null;
  } & TypedWalletScanOptions & DirectOperationEvidenceHashes & AuthoritativeTransferPreparationTime>(input: Input): Promise<PrivacyPreparationResult<Input, PreparedTransfer>>;
  prepareTransferBatch(input: PrepareTransferBatchInput): Promise<PreparedTransferBatch>;
  provePreparedBatchTransfer(input: {
    payload: PreparedBatchTransferPayload;
    proverAdapter: BatchTransferProverAdapter;
    signal?: AbortSignal;
    creator?: ClairAddress | string;
    denom?: string;
    nowUnix?: number;
    chainNowUnix?: number;
    chain_now_unix?: number;
  } & RequiredBatchTransferOperationIDBinding &
    RequiredReservationBatchBinding &
    RequiredPreparedBatchTransferProofCheckpoint): Promise<{
    payload: PreparedBatchTransferPayload;
    proof: PreparedBatchTransferProof & { proof_bytes: Uint8Array };
    message: MsgBatchTransferMessage;
    effects: { root_hex: Hex; nullifier_hexes: Hex[]; output_commitment_hexes: Hex[] };
    proofStageOnly: true;
    reservationFinalizationRequired: true;
  }>;
  finalizePreparedBatchTransfer(input: FinalizePreparedBatchTransferInput): Promise<FinalizedPreparedBatchTransfer>;
  prepareWithdraw<Input extends WalletPreparationContext & {
    amount: CoinString;
    recipient: ClairAddress;
    proverAdapter: ProverAdapter;
    signal?: AbortSignal;
    gasLimit?: number;
    gas_limit?: number;
    denom?: string;
    assetDenom?: string;
    page?: number;
    limit?: number;
    maxPages?: number;
    max_pages?: number;
    scan?: TypedWalletScanOptions;
    scanSource?: "privacy_scan";
    scan_source?: "privacy_scan";
    expiresAtUnix?: number;
    expires_at_unix?: number;
    chainNowUnix?: number;
    chain_now_unix?: number;
    /** Exact profile/caller-selected fee coins, snapshotted before proof preparation. */
    feeAmount?: readonly CosmosFeeCoin[];
    fee_amount?: readonly CosmosFeeCoin[];
    reservationManager?: NoteReservationManager | null;
    reservation_manager?: NoteReservationManager | null;
  } & TypedWalletScanOptions>(input: Input): Promise<PrivacyPreparationResult<Input, PreparedWithdraw>>;
  prepareRelayWithdraw(input: {
    wallet?: WalletAdapterLike;
    material?: PrivacyMaterial;
    amount: CoinString;
    recipient: ClairAddress;
    proverAdapter: ProverAdapter;
    signal?: AbortSignal;
    denom?: string;
    assetDenom?: string;
    page?: number;
    limit?: number;
    maxPages?: number;
    max_pages?: number;
    scan?: TypedWalletScanOptions;
    scanSource?: "privacy_scan";
    scan_source?: "privacy_scan";
    expiresAtUnix?: number;
    expires_at_unix?: number;
    reservationManager?: NoteReservationManager | null;
    reservation_manager?: NoteReservationManager | null;
  } & TypedWalletScanOptions & RelayChainTimeInput): Promise<PreparedRelayWithdraw>;
  createDepositSignDoc(input: Parameters<ClairveilJS["prepareDeposit"]>[0]): Promise<PreparedDeposit>;
  createTransferSignDoc(input: Omit<Parameters<ClairveilJS["prepareTransfer"]>[0], "executionBuilder"> & { executionBuilder?: never }): Promise<PreparedTransfer & { status: "ready"; signDoc: SignDocBase64 }>;
  createTransferBatchSignDoc(input: Omit<Parameters<ClairveilJS["prepareTransferBatch"]>[0], "executionBuilder"> & { executionBuilder?: never }): Promise<PreparedTransferBatch & { status: "ready"; signDoc: SignDocBase64 }>;
  createBatchTransferSignDoc(input: {
    signer: ClairAddress;
    pubKeyHex: Hex;
    gasLimit?: number | bigint;
    gas_limit?: number | bigint;
    feeAmount?: readonly CosmosFeeCoin[];
    fee_amount?: readonly CosmosFeeCoin[];
    message: MsgBatchTransferMessage;
    memo?: string;
    expectedCircuitIdentity?: ValidatedCircuitConfigV1["circuit_set_identity"];
    chainNowUnix?: number;
    chain_now_unix?: number;
  }): Promise<SignDocBase64>;
  createWithdrawSignDoc(input: Omit<Parameters<ClairveilJS["prepareWithdraw"]>[0], "executionBuilder"> & { executionBuilder?: never }): Promise<PreparedWithdrawReady>;
  createRelayWithdrawPayload(input: Parameters<ClairveilJS["prepareRelayWithdraw"]>[0]): Promise<PreparedRelayWithdraw & { status: "ready"; payload: PreparedWithdrawPayload }>;
  buildPreparedTransferPayload(input: PreparedTransferPayloadInput & { chainNowUnix: number }): Promise<PreparedTransferPayload>;
  buildTransferMessage(input: PreparedTransferPayloadInput & AuthoritativeTransferPreparationTime & {
    expires_at_unix?: number;
    proverAdapter: ProverAdapter;
    checkNullifiers?: import("../privacy/payload.js").NullifierStatusReader;
    signal?: AbortSignal;
  }): Promise<TransferMessageBuildResult>;
  buildPreparedWithdrawProverPayload(input: PreparedWithdrawProverPayloadInput): Promise<PreparedWithdrawProverPayloadResult>;
  buildRelayWithdrawPayload(input: Omit<PreparedWithdrawProverPayloadInput, "chainNowUnix"> & {
    chainNowUnix: number;
    proverAdapter: ProverAdapter;
    checkNullifiers?: import("../privacy/payload.js").NullifierStatusReader;
    signal?: AbortSignal;
  }): Promise<RelayWithdrawPayloadBuildResult>;
  buildWithdrawMessage(input: PreparedWithdrawProverPayloadInput & {
    proverAdapter: ProverAdapter;
    creator?: ClairAddress | string;
    checkNullifiers?: import("../privacy/payload.js").NullifierStatusReader;
    signal?: AbortSignal;
  }): Promise<WithdrawMessageBuildResult>;
  buildRelayWithdrawMessageFromPayload(input: {
    payload: PreparedWithdrawPayload;
    relayer?: ClairAddress | string;
    creator?: ClairAddress | string;
  } & CosmosRelayWithdrawRelayOptions): WithdrawMessage;
  createRelayWithdrawSignDoc(input: {
    payload: PreparedWithdrawPayload;
    relayer?: ClairAddress | string;
    creator?: ClairAddress | string;
    pubKeyHex?: Hex;
    pub_key_hex?: Hex;
    gasLimit?: number;
    feeAmount?: readonly CosmosFeeCoin[];
    memo?: string;
  } & CosmosRelayWithdrawRelayOptions): Promise<PreparedRelayWithdrawSignDoc>;
  decodeUserDisclosure(input: {
    /** Validator-issued shielded-transfer recipient output; avoids raw event lookup. */
    output?: import("../core/disclosure.js").PrivacyScanDisclosureOutputV2;
    scanOutput?: import("../core/disclosure.js").PrivacyScanDisclosureOutputV2;
    txHash?: Hex;
    tx_hash?: Hex;
    address?: ClairAddress;
    pubKeyHex?: Hex;
    pub_key_hex?: Hex;
    signatureBase64?: Base64;
    signature_base64?: Base64;
    skipSignerPubKeyCheck?: boolean;
    skip_signer_pubkey_check?: boolean;
    disclosureScalar?: bigint | string | number;
    disclosure_scalar?: bigint | string | number;
    disclosureScalarHex?: Hex;
    disclosure_scalar_hex?: Hex;
    disclosurePubKeyHex?: Hex;
    disclosure_pubkey_hex?: Hex;
    /** Optional denom override, independently verified against the disclosure asset field. */
    assetDenom?: string;
    /** Alias for `assetDenom`. */
    asset_denom?: string;
  } & PrivacyScanOptions): Promise<import("../core/disclosure.js").DisclosureReport>;
  decodeSelfViewDisclosure(input: {
    /** Validator-issued shielded-transfer recipient output; avoids raw event lookup. */
    output?: import("../core/disclosure.js").PrivacyScanDisclosureOutputV2;
    scanOutput?: import("../core/disclosure.js").PrivacyScanDisclosureOutputV2;
    txHash?: Hex;
    tx_hash?: Hex;
    address?: ClairAddress;
    pubKeyHex?: Hex;
    pub_key_hex?: Hex;
    signatureBase64?: Base64;
    signature_base64?: Base64;
    skipSignerPubKeyCheck?: boolean;
    skip_signer_pubkey_check?: boolean;
    disclosureScalar?: bigint | string | number;
    disclosure_scalar?: bigint | string | number;
    disclosureScalarHex?: Hex;
    disclosure_scalar_hex?: Hex;
    /** Optional denom override, independently verified against the disclosure asset field. */
    assetDenom?: string;
    /** Alias for `assetDenom`. */
    asset_denom?: string;
  } & PrivacyScanOptions): Promise<import("../core/disclosure.js").DisclosureReport>;
  decodeAuditDisclosure(input: {
    /** Validator-issued shielded-transfer recipient output; avoids raw event lookup. */
    output?: import("../core/disclosure.js").PrivacyScanDisclosureOutputV2;
    scanOutput?: import("../core/disclosure.js").PrivacyScanDisclosureOutputV2;
    txHash?: Hex;
    tx_hash?: Hex;
    disclosurePrivKeyHex?: Hex;
    disclosure_privkey_hex?: Hex;
    /** Optional denom override, independently verified against the disclosure asset field. */
    assetDenom?: string;
    /** Alias for `assetDenom`. */
    asset_denom?: string;
  } & PrivacyScanOptions): Promise<import("../core/disclosure.js").DisclosureReport>;
  decodeBatchUserDisclosure(input: {
    /** One output from `validatePrivacyScanPageV2`, never a lossy ABCI event. */
    output?: import("../core/disclosure.js").BatchPrivacyScanDisclosureOutputV2;
    /** Alias for `output`. */
    scanOutput?: import("../core/disclosure.js").BatchPrivacyScanDisclosureOutputV2;
    txHash?: Hex;
    tx_hash?: Hex;
    address?: ClairAddress;
    pubKeyHex?: Hex;
    pub_key_hex?: Hex;
    signatureBase64?: Base64;
    signature_base64?: Base64;
    skipSignerPubKeyCheck?: boolean;
    skip_signer_pubkey_check?: boolean;
    disclosureScalar?: bigint | string | number;
    disclosure_scalar?: bigint | string | number;
    disclosureScalarHex?: Hex;
    disclosure_scalar_hex?: Hex;
    disclosurePubKeyHex?: Hex;
    disclosure_pubkey_hex?: Hex;
    assetDenom?: string;
    asset_denom?: string;
  }): Promise<import("../core/disclosure.js").DisclosureReport>;
  decodeBatchSelfViewDisclosure(input: {
    /** One output from `validatePrivacyScanPageV2`, never a lossy ABCI event. */
    output?: import("../core/disclosure.js").BatchPrivacyScanDisclosureOutputV2;
    /** Alias for `output`. */
    scanOutput?: import("../core/disclosure.js").BatchPrivacyScanDisclosureOutputV2;
    txHash?: Hex;
    tx_hash?: Hex;
    address?: ClairAddress;
    pubKeyHex?: Hex;
    pub_key_hex?: Hex;
    signatureBase64?: Base64;
    signature_base64?: Base64;
    skipSignerPubKeyCheck?: boolean;
    skip_signer_pubkey_check?: boolean;
    disclosureScalar?: bigint | string | number;
    disclosure_scalar?: bigint | string | number;
    disclosureScalarHex?: Hex;
    disclosure_scalar_hex?: Hex;
    assetDenom?: string;
    asset_denom?: string;
  }): Promise<import("../core/disclosure.js").DisclosureReport>;
  decodeBatchAuditDisclosure(input: {
    /** One output from `validatePrivacyScanPageV2`, never a lossy ABCI event. */
    output?: import("../core/disclosure.js").BatchPrivacyScanDisclosureOutputV2;
    /** Alias for `output`. */
    scanOutput?: import("../core/disclosure.js").BatchPrivacyScanDisclosureOutputV2;
    txHash?: Hex;
    tx_hash?: Hex;
    disclosurePrivKeyHex?: Hex;
    disclosure_privkey_hex?: Hex;
    disclosureScalar?: bigint | string | number;
    disclosure_scalar?: bigint | string | number;
    disclosureScalarHex?: Hex;
    disclosure_scalar_hex?: Hex;
    assetDenom?: string;
    asset_denom?: string;
  }): Promise<import("../core/disclosure.js").DisclosureReport>;
  buildDirectSignDoc(input: {
    signer: ClairAddress;
    pubKeyHex: Hex;
    messages: Array<{ typeUrl: string; value: object }>;
    memo?: string;
    gasLimit?: number;
    feeAmount?: readonly CosmosFeeCoin[];
  }): Promise<SignDocBase64>;
  buildTxRawBytes(signedTx: SignedTxBase64): Uint8Array;
  /** Broadcast exact pre-encoded TxRaw bytes without re-encoding them. */
  broadcastTxRawBytes(txRawBytes: Uint8Array, waitOptions?: ReservationBroadcastOptions): Promise<BroadcastSignedTxResult>;
  broadcastSignedTx(signedTx: SignedTxBase64, waitOptions?: ReservationBroadcastOptions): Promise<BroadcastSignedTxResult>;
  /** Sign without broadcasting so callers can durably checkpoint exact TxRaw bytes first. */
  signDirect(input: ReservationBroadcastOptions & { wallet: WalletAdapterLike; signDoc: SignDocBase64; waitOptions?: { attempts?: number; intervalMs?: number } }): Promise<SignedTxRawCheckpoint>;
  /**
   * Reservation-aware signing keeps the operation lease alive from before the
   * wallet prompt through the durable broadcast outcome write. A bound
   * reservation manager must therefore provide renewLease.
   */
  signDirectAndBroadcast(input: ReservationBroadcastOptions & { wallet: WalletAdapterLike; signDoc: SignDocBase64; waitOptions?: { attempts?: number; intervalMs?: number } }): Promise<BroadcastSignedTxResult>;
}

export function createClairveilClient(options: ClairveilClientOptions): ClairveilJS;

export function nextPrivacyScanOptions(scanOrCursor?: object, defaults?: PrivacyScanOptions & {
  includeFoundNotes?: boolean;
}): PrivacyScanResumeOptions;
