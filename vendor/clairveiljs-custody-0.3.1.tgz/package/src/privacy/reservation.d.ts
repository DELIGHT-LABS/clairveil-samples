import type { BytesLike, Hex } from "../core/crypto.js";
import type { FoundNote } from "../core/note.js";
import type { NullifierStatusResult } from "./payload.js";
import type { TransferBatchPlan, TransferPlan, WithdrawPlan } from "./planner.js";

export declare const reservationStatuses: Readonly<{
  Discovered: "Discovered";
  Available: "Available";
  Reserved: "Reserved";
  Proving: "Proving";
  ProofReady: "ProofReady";
  Submitted: "Submitted";
  ConfirmedSpent: "ConfirmedSpent";
  Failed: "Failed";
  ReplanRequired: "ReplanRequired";
  Released: "Released";
  Unknown: "Unknown";
  ManualReview: "ManualReview";
}>;

export declare const operationStatuses: Readonly<{
  Planned: "Planned";
  Proving: "Proving";
  ProofReady: "ProofReady";
  Submitted: "Submitted";
  Succeeded: "Succeeded";
  Failed: "Failed";
  ReplanRequired: "ReplanRequired";
  Unknown: "Unknown";
  ManualReview: "ManualReview";
  ConflictSpent: "ConflictSpent";
}>;

export type ReservationStatus = typeof reservationStatuses[keyof typeof reservationStatuses];
export type OperationStatus = typeof operationStatuses[keyof typeof operationStatuses];
export type ReservationExecutionTransport = "cosmos" | "evm" | "external";
export type ReservationMetadataValue =
  | string
  | number
  | boolean
  | null
  | readonly ReservationMetadataValue[]
  | { readonly [key: string]: ReservationMetadataValue };
export type ReservationMetadata = Record<string, ReservationMetadataValue>;

export const privacyReservationStateVersionV1: "privacy-note-v1-reservation-v1";
export const privacyReservationStateIdentityV1: Readonly<{
  circuit_set_id: "privacy-note-v1";
  payload_version: "privacy-fixed-v1";
}>;

export interface ReservationStoreState {
  version: typeof privacyReservationStateVersionV1;
  circuit_set_id: "privacy-note-v1";
  payload_version: "privacy-fixed-v1";
  reservations: NoteReservationRecord[];
}

export interface ReservationStoreStateInput {
  version?: string | number;
  circuit_set_id?: string;
  payload_version?: string;
  reservations?: Partial<NoteReservationRecord>[];
}

export declare const activeReservationStatuses: readonly ReservationStatus[];

export interface BroadcastReservationContext {
  reservationManager: Pick<NoteReservationManager, "getReservation">;
  reservationIDs: readonly string[];
  leaseToken?: string;
}

export type ReservedInputNullifierStatuses = NullifierStatusResult;
export type BatchNullifierStatuses = ReservedInputNullifierStatuses;

export declare function getBroadcastReservationRecords(
  context: BroadcastReservationContext | null | undefined
): Promise<NoteReservationRecord[]>;
export declare function assertBatchTransferNullifiersUnspent(
  statuses: BatchNullifierStatuses,
  nullifiers: readonly string[]
): void;
export declare function assertReservedInputNullifiersUnspent(
  statuses: ReservedInputNullifierStatuses,
  nullifiers: readonly string[]
): void;
export declare function recheckReservedInputNullifiers(
  context: BroadcastReservationContext | null | undefined,
  checkNullifiers?: (nullifiers: readonly string[]) => Promise<ReservedInputNullifierStatuses> | ReservedInputNullifierStatuses,
  fallbackNullifiers?: readonly string[]
): Promise<readonly string[]>;
export declare function recheckReservedBatchTransferNullifiers(
  context: BroadcastReservationContext | null | undefined,
  checkNullifiers?: (nullifiers: readonly string[]) => Promise<BatchNullifierStatuses> | BatchNullifierStatuses
): Promise<readonly string[]>;

export interface NoteReservationRecord {
  reservation_id: string;
  operation_id: string;
  owner_key_id: string;
  nullifier_lookup_key: string;
  nullifier_lookup_key_id: string;
  status: ReservationStatus | string;
  lease_owner: string;
  lease_token: string;
  lease_until: string;
  last_heartbeat_at: string;
  kind: string;
  note_id: string;
  amount: string;
  tx_hash: string;
  height: number | string;
  sequence: number | string;
  payload_hash: string;
  expected_operation_evidence_hash: string;
  expected_output_commitment: string;
  expected_disclosure_digest: string;
  expected_recipient_hash: string;
  expected_amount: string;
  expected_amount_hash: string;
  expected_denom: string;
  batch_item_index: number;
  batch_item_index_known: boolean;
  sign_doc_hash: string;
  tx_bytes_hash: string;
  submitted_tx_hash: string;
  broadcast_attempt_count: number;
  broadcast_in_flight: boolean;
  /** Stable internal code only; external wallet/prover/RPC prose is never persisted. */
  last_broadcast_error: string;
  created_at: string;
  updated_at: string;
  metadata: ReservationMetadata;
}

type InitialReservationID =
  | { reservation_id: string; reservationID?: string; reservationId?: string }
  | { reservation_id?: string; reservationID: string; reservationId?: string }
  | { reservation_id?: string; reservationID?: string; reservationId: string };

type InitialReservationOwnerKeyID =
  | { owner_key_id: string; ownerKeyID?: string; ownerKeyId?: string }
  | { owner_key_id?: string; ownerKeyID: string; ownerKeyId?: string }
  | { owner_key_id?: string; ownerKeyID?: string; ownerKeyId: string };

type InitialReservationLookupKey =
  | { nullifier_lookup_key: string; nullifierLookupKey?: string }
  | { nullifier_lookup_key?: string; nullifierLookupKey: string };

/** Normal creation accepts only a clean Reserved record with its runtime-required identity; import fixtures through unsafe APIs. */
export type InitialNoteReservationRecord = Omit<Partial<NoteReservationRecord>,
  | "reservation_id"
  | "owner_key_id"
  | "nullifier_lookup_key"
  | "status"
  | "lease_owner"
  | "lease_token"
  | "lease_until"
  | "last_heartbeat_at"
  | "payload_hash"
  | "expected_operation_evidence_hash"
  | "expected_output_commitment"
  | "expected_disclosure_digest"
  | "expected_recipient_hash"
  | "expected_amount"
  | "expected_amount_hash"
  | "expected_denom"
  | "batch_item_index"
  | "batch_item_index_known"
  | "sign_doc_hash"
  | "tx_bytes_hash"
  | "submitted_tx_hash"
  | "broadcast_attempt_count"
  | "broadcast_in_flight"
  | "last_broadcast_error"
> & InitialReservationID & InitialReservationOwnerKeyID & InitialReservationLookupKey & {
  status?: "Reserved";
  lease_owner?: never;
  lease_token?: never;
  lease_until?: never;
  last_heartbeat_at?: never;
  payload_hash?: never;
  payloadHash?: never;
  expected_operation_evidence_hash?: never;
  expectedOperationEvidenceHash?: never;
  expected_output_commitment?: never;
  expectedOutputCommitment?: never;
  expected_disclosure_digest?: never;
  expectedDisclosureDigest?: never;
  expected_recipient_hash?: never;
  expectedRecipientHash?: never;
  expected_amount?: never;
  expectedAmount?: never;
  expected_amount_hash?: never;
  expectedAmountHash?: never;
  expected_denom?: never;
  expectedDenom?: never;
  batch_item_index?: never;
  batchItemIndex?: never;
  batch_item_index_known?: never;
  batchItemIndexKnown?: never;
  operation_success_evidence_required?: never;
  operationSuccessEvidenceRequired?: never;
  sign_doc_hash?: never;
  signDocHash?: never;
  tx_bytes_hash?: never;
  txBytesHash?: never;
  submitted_tx_hash?: never;
  submittedTxHash?: never;
  broadcast_attempt_count?: never;
  broadcastAttemptCount?: never;
  broadcast_in_flight?: never;
  broadcastInFlight?: never;
  last_broadcast_error?: never;
  lastBroadcastError?: never;
};

export type SpentNoteEvidence = (object | FoundNote) & (
  { spent: true } |
  { isSpent: true } |
  { is_spent: true }
);

export interface ReservationStore {
  load?: () => Promise<ReservationStoreState>;
  listReservations(filter?: { statuses?: readonly string[]; ownerKeyId?: string; owner_key_id?: string; limit?: number }): Promise<NoteReservationRecord[]>;
  getReservation(reservationID: string): Promise<NoteReservationRecord>;
  createReservationBatch(reservations: readonly InitialNoteReservationRecord[]): Promise<NoteReservationRecord[]>;
  compareAndSetReservationStatus(reservationID: string, from: string, to: string, patch?: Partial<NoteReservationRecord>): Promise<NoteReservationRecord>;
  compareAndSetReservationStatusBatch(transitions: readonly {
    /** If both aliases are supplied, their string values must match. */
    reservationID?: string;
    reservation_id?: string;
    from: string;
    to: string;
    patch?: Partial<NoteReservationRecord>;
  }[]): Promise<NoteReservationRecord[]>;
  /** Atomically releases only reservations that are still in Reserved. */
  releaseReservationBatch(options: {
    reservationIDs: readonly string[];
    ownerKeyId: string;
    leaseOwner?: string;
    leaseToken?: string;
  }): Promise<NoteReservationRecord[]>;
  findActiveReservationByLookupKey(ownerKeyId: string, lookupKey: string): Promise<NoteReservationRecord | null>;
  findReservationsByLookupKey(ownerKeyId: string, lookupKey: string): Promise<NoteReservationRecord[]>;
  reconcileSpentByLookupKey(ownerKeyId: string, lookupKey: string, note: SpentNoteEvidence, options?: { now?: string | Date }): Promise<NoteReservationRecord[]>;
  reconcileSpentByLookupKeys(ownerKeyId: string, spentNotes: Array<{ lookupKey: string; note: SpentNoteEvidence }>, options?: { now?: string | Date }): Promise<NoteReservationRecord[]>;
}

export interface ReservationLockManager {
  request<T>(
    name: string,
    options: { mode?: "exclusive" | "shared" },
    callback: () => T | Promise<T>
  ): Promise<T>;
}

export declare function isActiveReservationStatus(status: string): boolean;
export declare function canTransitionReservation(from: string, to: string): boolean;
export declare function requiresReservationLeaseToken(from: string, to: string): boolean;
/** True only for worker-owned cleanup transitions that may run after the stored lease has expired. */
export declare function canRecoverReservationAfterLeaseExpiry(from: string, to: string): boolean;
export declare function reservationHeartbeatIntervalMs(input?: {
  leaseDurationMs?: number;
  lease_duration_ms?: number;
  leaseUntil?: string | Date;
  lease_until?: string | Date;
  minIntervalMs?: number;
  maxIntervalMs?: number;
  now?: string | Date;
}): number;
/** Computes a lookup key from raw nullifier bytes or a non-hex string label. For 32-byte nullifier hex strings, use nullifierLookupKeyFromHex. */
export declare function nullifierLookupKey(indexKey: BytesLike | string, nullifier: BytesLike | string): Hex;
/** Computes a lookup key from a 32-byte nullifier hex string. */
export declare function nullifierLookupKeyFromHex(indexKey: BytesLike | string, nullifierHex: Hex | string): Hex;
/** Go-compatible SHA-256 hash of a canonical shielded recipient for operation success evidence. */
export declare function hashRecipient(recipient: string, options?: string | {
  shieldedPrefix?: string;
  prefix?: string;
}): Hex;
/** SHA-256 hash of a canonical 20-byte Cosmos account recipient for direct-withdraw success evidence. */
export declare function hashTransparentRecipient(recipient: string, options?: string | {
  accountPrefix?: string;
  bech32Prefix?: string;
}): Hex;
/** Go-compatible SHA-256 hash of canonical non-empty denom and uint64 `denom:amount` operation evidence. */
export declare function hashAmount(denom: string, amount: bigint | number | string): Hex;
export declare function noteNullifierHex(noteLike: object | FoundNote): Hex;
export declare function noteReservationIdentity(noteLike: object | FoundNote): {
  nullifierHex: Hex;
  noteId: string;
  amount: string;
  height: number | string;
  sequence: number | string;
  txHash: string;
};
export declare function selectedReservationNotesFromPlan(plan?: TransferPlan | TransferBatchPlan | WithdrawPlan | object | null): FoundNote[];

export declare class MemoryReservationStore implements ReservationStore {
  constructor(input?: {
    state?: ReservationStoreStateInput;
    /** Store-local clock used when validating lease state inside atomic mutations. */
    now?: () => Date;
  });
  load(): Promise<ReservationStoreState>;
  listReservations(filter?: { statuses?: readonly string[]; ownerKeyId?: string; owner_key_id?: string; limit?: number }): Promise<NoteReservationRecord[]>;
  getReservation(reservationID: string): Promise<NoteReservationRecord>;
  createReservationBatch(reservations?: readonly InitialNoteReservationRecord[]): Promise<NoteReservationRecord[]>;
  compareAndSetReservationStatus(reservationID: string, from: string, to: string, patch?: Partial<NoteReservationRecord>): Promise<NoteReservationRecord>;
  compareAndSetReservationStatusBatch(transitions?: readonly {
    /** If both aliases are supplied, their string values must match. */
    reservationID?: string;
    reservation_id?: string;
    from: string;
    to: string;
    patch?: Partial<NoteReservationRecord>;
  }[]): Promise<NoteReservationRecord[]>;
  /** Atomically releases only reservations that are still in Reserved. */
  releaseReservationBatch(options: {
    reservationIDs: readonly string[];
    ownerKeyId: string;
    leaseOwner?: string;
    leaseToken?: string;
  }): Promise<NoteReservationRecord[]>;
  findActiveReservationByLookupKey(ownerKeyId: string, lookupKey: string): Promise<NoteReservationRecord | null>;
  findReservationsByLookupKey(ownerKeyId: string, lookupKey: string): Promise<NoteReservationRecord[]>;
  reconcileSpentByLookupKey(ownerKeyId: string, lookupKey: string, note: SpentNoteEvidence, options?: { now?: string | Date }): Promise<NoteReservationRecord[]>;
  reconcileSpentByLookupKeys(ownerKeyId: string, spentNotes: Array<{ lookupKey: string; note: SpentNoteEvidence }>, options?: { now?: string | Date }): Promise<NoteReservationRecord[]>;
}

export declare class IndexedDbReservationStore extends MemoryReservationStore {
  constructor(input?: {
    dbName?: string;
    namespace?: string;
    indexedDB?: IDBFactory;
    locks?: ReservationLockManager | null;
    requireLocks?: boolean;
    require_locks?: boolean;
    /** Encodes the full reservation state before writing it to IndexedDB. Provide with decodeState in production. */
    encodeState?: (state: ReservationStoreState) => object | string | number | boolean | bigint | Promise<object | string | number | boolean | bigint>;
    encode_state?: (state: ReservationStoreState) => object | string | number | boolean | bigint | Promise<object | string | number | boolean | bigint>;
    /** Decodes the value read from IndexedDB. Provide with encodeState in production. */
    decodeState?: (value: unknown) => ReservationStoreStateInput | Promise<ReservationStoreStateInput>;
    decode_state?: (value: unknown) => ReservationStoreStateInput | Promise<ReservationStoreStateInput>;
    /** Explicit demo/test-only opt-in for plaintext IndexedDB state. */
    unsafeAllowPlaintext?: boolean;
    unsafe_allow_plaintext?: boolean;
    /** Store-local clock used when validating lease state inside atomic mutations. */
    now?: () => Date;
  });
}

export declare function createBrowserReservationStore(options?: {
  dbName?: string;
  namespace?: string;
  indexedDB?: IDBFactory | null;
  locks?: ReservationLockManager | null;
  requireLocks?: boolean;
  require_locks?: boolean;
  encodeState?: (state: ReservationStoreState) => object | string | number | boolean | bigint | Promise<object | string | number | boolean | bigint>;
  encode_state?: (state: ReservationStoreState) => object | string | number | boolean | bigint | Promise<object | string | number | boolean | bigint>;
  decodeState?: (value: unknown) => ReservationStoreStateInput | Promise<ReservationStoreStateInput>;
  decode_state?: (value: unknown) => ReservationStoreStateInput | Promise<ReservationStoreStateInput>;
  unsafeAllowPlaintext?: boolean;
  unsafe_allow_plaintext?: boolean;
  /** Explicit demo/test-only opt-in when IndexedDB is unavailable. */
  unsafeAllowMemoryFallback?: boolean;
  unsafe_allow_memory_fallback?: boolean;
  now?: () => Date;
  state?: ReservationStoreStateInput;
}): ReservationStore;

type NoteReservationOwnerInput =
  | { ownerKeyId: string; owner_key_id?: string }
  | { ownerKeyId?: string; owner_key_id: string };

type NoteReservationManagerBaseInput = {
  store: ReservationStore;
  nullifierLookupKeyId?: string;
  nullifier_lookup_key_id?: string;
  leaseOwner?: string;
  lease_owner?: string;
  leaseDurationMs?: number;
  lease_duration_ms?: number;
  now?: () => Date;
} & NoteReservationOwnerInput;

export type NoteReservationManagerInput = NoteReservationManagerBaseInput & (
  | { indexKey: BytesLike | string; index_key?: BytesLike | string; unsafeAllowPublicIndexKey?: false; unsafe_allow_public_index_key?: false }
  | { index_key: BytesLike | string; indexKey?: BytesLike | string; unsafeAllowPublicIndexKey?: false; unsafe_allow_public_index_key?: false }
  | { indexKey?: BytesLike | string; index_key?: BytesLike | string; unsafeAllowPublicIndexKey: true; unsafe_allow_public_index_key?: boolean }
  | { indexKey?: BytesLike | string; index_key?: BytesLike | string; unsafeAllowPublicIndexKey?: boolean; unsafe_allow_public_index_key: true }
);

export interface ReservationBatch {
  operation_id: string;
  lease_owner: string;
  lease_token: string;
  lease_until: string;
  reservation_ids: string[];
  reservations: NoteReservationRecord[];
}

export interface ReservationLeaseMetadata {
  leaseToken?: string;
  lease_token?: string;
  leaseOwner?: string;
  lease_owner?: string;
  leaseUntil?: string | Date;
  lease_until?: string | Date;
  leaseDurationMs?: number;
  lease_duration_ms?: number;
}

/** `markProving` claims a manager-owned lease; only the generated batch token is accepted. */
export interface ReservationProvingMetadata {
  leaseToken?: string;
  lease_token?: string;
}

export interface ReservationOperationSuccessEvidenceMetadata {
  operationSuccessEvidenceRequired?: boolean;
  operation_success_evidence_required?: boolean;
  operationEvidenceHash?: string;
  operation_evidence_hash?: string;
  expectedOperationEvidenceHash?: string;
  expected_operation_evidence_hash?: string;
  txHash?: string;
  tx_hash?: string;
  txhash?: string;
  submittedTxHash?: string;
  submitted_tx_hash?: string;
  txHashSubmitted?: string;
  transactionHash?: string;
  transaction_hash?: string;
  transaction_hash_hex?: string;
  txBytesHash?: string;
  tx_bytes_hash?: string;
  txBytes?: string;
  tx_bytes?: string;
  signDocHash?: string;
  sign_doc_hash?: string;
  signDoc?: string;
  sign_doc?: string;
  txResult?: object;
  tx_result?: object;
  transactionResult?: object;
  transaction_result?: object;
  /** Set by strict EVM confirmation after RPC transaction identity verification. */
  evmTransactionVerified?: boolean;
  evm_transaction_verified?: boolean;
  transactionVerified?: boolean;
  transaction_verified?: boolean;
  /** Set by strict EVM confirmation after action-specific Privacy* event verification. */
  evmPrivacyReceiptVerified?: boolean;
  evm_privacy_receipt_verified?: boolean;
  evmFinalityVerified?: boolean;
  evm_finality_verified?: boolean;
  finality?: { verified?: boolean; [key: string]: unknown };
  evmFinality?: { verified?: boolean; [key: string]: unknown };
  evm_finality?: { verified?: boolean; [key: string]: unknown };
  privacyReceiptVerified?: boolean;
  privacy_receipt_verified?: boolean;
  expectedOutputCommitment?: string;
  expected_output_commitment?: string;
  outputCommitment?: string;
  output_commitment?: string;
  outputCommitmentHex?: string;
  output_commitment_hex?: string;
  expectedDisclosureDigest?: string;
  expected_disclosure_digest?: string;
  auditDisclosureDigest?: string;
  audit_disclosure_digest?: string;
  auditDisclosureDigestHex?: string;
  audit_disclosure_digest_hex?: string;
  expectedRecipientHash?: string;
  expected_recipient_hash?: string;
  recipientHash?: string;
  recipient_hash?: string;
  expectedAmount?: string;
  expected_amount?: string;
  expectedAmountHash?: string;
  expected_amount_hash?: string;
  amountHash?: string;
  amount_hash?: string;
  expectedDenom?: string;
  expected_denom?: string;
  denom?: string;
  assetDenom?: string;
  asset_denom?: string;
  batchItemIndex?: number | string;
  batch_item_index?: number | string;
  itemIndex?: number | string;
  item_index?: number | string;
  batchItemIndexKnown?: boolean;
  batch_item_index_known?: boolean;
}

export type ReservationProofReadyMetadata = ReservationLeaseMetadata & ReservationOperationSuccessEvidenceMetadata & {
  payloadHash?: string;
  payload_hash?: string;
  signDocHash?: string;
  sign_doc_hash?: string;
  txBytesHash?: string;
  tx_bytes_hash?: string;
  /** Write-once execution semantics used by operation reconciliation. */
  executionTransport?: ReservationExecutionTransport;
  execution_transport?: ReservationExecutionTransport;
  metadata?: ReservationMetadata;
};

export type ReservationProofReadyBatchEntry = {
  /** If both aliases are supplied, they must contain the same IDs in the same order. */
  reservationIDs?: readonly string[];
  reservation_ids?: readonly string[];
  metadata?: ReservationProofReadyMetadata;
};

type ReservationBroadcastMetadataFields = {
  broadcastAttemptCount?: number;
  broadcast_attempt_count?: number;
  metadata?: ReservationMetadata;
};

type ReservationBroadcastAttemptFields = {
  txHash?: string;
  tx_hash?: string;
  submittedTxHash?: string;
  submitted_tx_hash?: string;
  txHashSubmitted?: string;
  txBytesHash?: string;
  tx_bytes_hash?: string;
  signDocHash?: string;
  sign_doc_hash?: string;
};

type ReservationSubmittedBroadcastAttempt = ReservationBroadcastAttemptFields & (
  | { txHash: string }
  | { tx_hash: string }
  | { submittedTxHash: string }
  | { submitted_tx_hash: string }
  | { txHashSubmitted: string }
  | { txBytesHash: string }
  | { tx_bytes_hash: string }
);

export type ReservationSubmittedMetadata = ReservationLeaseMetadata & ReservationBroadcastMetadataFields & ReservationSubmittedBroadcastAttempt;

export interface ReservationDurableErrorMetadata {
  /** Preferred stable internal code. Non-code-shaped values are discarded. */
  errorCode?: string;
  error_code?: string;
  /** Compatibility inputs for transient errors; their values are not persisted as durable codes. */
  error?: string;
  lastBroadcastError?: string;
  last_broadcast_error?: string;
}

export type ReservationRelaySubmissionMetadata = ReservationLeaseMetadata & ReservationBroadcastMetadataFields & ReservationBroadcastAttemptFields & (
  | { payloadHash: string; payload_hash?: string }
  | { payload_hash: string; payloadHash?: string }
) & (
  | { txHash: string; tx_hash?: string; submittedTxHash?: string; submitted_tx_hash?: string; txHashSubmitted?: string }
  | { tx_hash: string; txHash?: string; submittedTxHash?: string; submitted_tx_hash?: string; txHashSubmitted?: string }
  | { submittedTxHash: string; txHash?: string; tx_hash?: string; submitted_tx_hash?: string; txHashSubmitted?: string }
  | { submitted_tx_hash: string; txHash?: string; tx_hash?: string; submittedTxHash?: string; txHashSubmitted?: string }
  | { txHashSubmitted: string; txHash?: string; tx_hash?: string; submittedTxHash?: string; submitted_tx_hash?: string }
);

export type ReservationUnknownMetadata = ReservationLeaseMetadata & ReservationBroadcastMetadataFields & ReservationSubmittedBroadcastAttempt & ReservationDurableErrorMetadata & {
  fromStatus?: "ProofReady" | "Submitted";
  from_status?: "ProofReady" | "Submitted";
  /** Explicit CheckTx evidence retains the reservation in Unknown until authoritative reconciliation. */
  providerCode?: string | number;
  provider_code?: string | number;
  providerCodespace?: string;
  provider_codespace?: string;
  rpcInvoked?: true;
  rpc_invoked?: true;
  checkTxRejected?: true;
  check_tx_rejected?: true;
};

type RequiredAliasedValue<Camel extends string, Snake extends string, Value> =
  | ({ [Key in Camel]: Value } & { [Key in Snake]?: Value })
  | ({ [Key in Snake]: Value } & { [Key in Camel]?: Value });

export type ReservationRelayTransactionEvidence =
  RequiredAliasedValue<"operationId", "operation_id", string> &
  RequiredAliasedValue<"payloadHash", "payload_hash", string> &
  RequiredAliasedValue<"txHash", "tx_hash", string> &
  RequiredAliasedValue<"checkedHeight", "checked_height", number | string> &
  RequiredAliasedValue<"transactionIncludedConfirmed", "transaction_included_confirmed", true> &
  RequiredAliasedValue<"payloadHashMatched", "payload_hash_matched", true>;

export type ReservationBroadcastFailureEvidence =
  RequiredAliasedValue<"txHashChecked", "tx_hash_checked", string> &
  RequiredAliasedValue<"checkedHeight", "checked_height", number | string> &
  RequiredAliasedValue<"nullifierUnspentConfirmed", "nullifier_unspent_confirmed", true> &
  RequiredAliasedValue<"txAbsentOrFailedConfirmed", "tx_absent_or_failed_confirmed", true> &
  ReservationDurableErrorMetadata & {
  metadata?: ReservationMetadata;
};

export type ExpiredProofReadyBroadcastFailureRecovery =
  RequiredAliasedValue<"operationId", "operation_id", string> &
  RequiredAliasedValue<"txHashChecked", "tx_hash_checked", string> &
  RequiredAliasedValue<"checkedHeight", "checked_height", number | string> &
  RequiredAliasedValue<"txBytesHash", "tx_bytes_hash", string> &
  RequiredAliasedValue<"signDocHash", "sign_doc_hash", string> &
  RequiredAliasedValue<"executionFailedConfirmed", "execution_failed_confirmed", true> &
  RequiredAliasedValue<"inputNullifiers", "input_nullifiers", readonly Hex[]> &
  RequiredAliasedValue<
    "checkNullifiers",
    "check_nullifiers",
    import("./payload.js").NullifierStatusReader
  > & ReservationDurableErrorMetadata & {
  metadata?: ReservationMetadata;
};

export interface ReservationReplanMetadata extends ReservationLeaseMetadata, ReservationDurableErrorMetadata {
  fromStatus?: string;
  from_status?: string;
  txHash?: string;
  tx_hash?: string;
  txBytesHash?: string;
  tx_bytes_hash?: string;
  signDocHash?: string;
  sign_doc_hash?: string;
  /** Required when replanning a Submitted or Unknown reservation so callers prove the nullifier was checked unspent. */
  nullifierUnspentConfirmed?: boolean;
  nullifier_unspent_confirmed?: boolean;
  /** Required with nullifierUnspentConfirmed for Submitted or Unknown: the recorded tx was confirmed absent or failed. */
  txAbsentOrFailedConfirmed?: boolean;
  tx_absent_or_failed_confirmed?: boolean;
  checkedHeight?: number | string;
  checked_height?: number | string;
  txHashChecked?: string;
  tx_hash_checked?: string;
  /** Required when discarding a local ProofReady proof before any broadcast attempt. */
  proofDiscarded?: boolean;
  proof_discarded?: boolean;
  /** Required with relay_payload_expired when an authoritative chain block time established expiry. */
  authoritativeExpiryConfirmed?: boolean;
  authoritative_expiry_confirmed?: boolean;
  metadata?: ReservationMetadata;
}

/** Operator approval required to make a ManualReview note available again. */
export interface ReservationManualReviewResolution {
  target: "Released" | "ReplanRequired" | "Failed";
  operatorId: string;
  approvalReference: string;
  reason?: string;
  metadata?: ReservationMetadata;
}

export declare class NoteReservationManager {
  store: ReservationStore;
  ownerKeyId: string;
  nullifierLookupKeyId: string;
  leaseOwner: string;
  leaseDurationMs: number;
  constructor(input: NoteReservationManagerInput);
  lookupKeyForNote(noteLike: object | FoundNote): Promise<Hex>;
  listActiveReservations(): Promise<NoteReservationRecord[]>;
  getReservation(reservationID: string): Promise<NoteReservationRecord>;
  /** Reads an exact reservation set from one persistent-state snapshot. */
  getReservations(reservationIDs?: readonly string[]): Promise<NoteReservationRecord[]>;
  reservationForNote(noteLike: object | FoundNote): Promise<NoteReservationRecord | null>;
  reservationStatusByNote(notes?: readonly (object | FoundNote)[]): Promise<Map<string, NoteReservationRecord | null>>;
  filterAvailableNotes<T extends object | FoundNote>(notes?: readonly T[]): Promise<T[]>;
  reserveNotes(input?: { notes?: readonly (object | FoundNote)[]; operationId?: string; operation_id?: string; kind?: string; metadata?: ReservationMetadata }): Promise<ReservationBatch>;
  reservePlan(input?: { plan?: TransferPlan | TransferBatchPlan | WithdrawPlan | object | null; kind?: string; operationId?: string; operation_id?: string; metadata?: ReservationMetadata }): Promise<ReservationBatch>;
  transitionBatch(reservationIDs: readonly string[], from: string, to: string, patch?: Partial<NoteReservationRecord>): Promise<NoteReservationRecord[]>;
  renewLease(reservationIDs?: readonly string[], metadata?: ReservationLeaseMetadata): Promise<NoteReservationRecord[]>;
  heartbeatLease(reservationIDs?: readonly string[], metadata?: ReservationLeaseMetadata): Promise<NoteReservationRecord[]>;
  markProving(reservationIDs?: readonly string[], metadata?: ReservationProvingMetadata): Promise<NoteReservationRecord[]>;
  markProofReady(reservationIDs?: readonly string[], metadata?: ReservationProofReadyMetadata): Promise<NoteReservationRecord[]>;
  markProofReadyBatch(entries?: readonly ReservationProofReadyBatchEntry[]): Promise<NoteReservationRecord[]>;
  markBroadcastAttempting(reservationIDs: readonly string[], metadata: ReservationLeaseMetadata & ReservationBroadcastAttemptFields & { reason?: string; metadata?: ReservationMetadata }): Promise<NoteReservationRecord[]>;
  markBroadcastRejected(reservationIDs: readonly string[], metadata: ReservationLeaseMetadata & ReservationDurableErrorMetadata & {
    providerCode?: string | number;
    provider_code?: string | number;
    providerCodespace?: string;
    provider_codespace?: string;
    rpcInvoked?: false;
    rpc_invoked?: false;
    checkTxRejected?: never;
    check_tx_rejected?: never;
    broadcastAbortedBeforeRpc?: boolean;
    broadcast_aborted_before_rpc?: boolean;
    walletRejectedBeforeBroadcast?: boolean;
    wallet_rejected_before_broadcast?: boolean;
    metadata?: ReservationMetadata;
  }): Promise<NoteReservationRecord[]>;
  markSubmitted(reservationIDs: readonly string[], metadata: ReservationSubmittedMetadata): Promise<NoteReservationRecord[]>;
  markUnknown(reservationIDs: readonly string[], metadata: ReservationUnknownMetadata): Promise<NoteReservationRecord[]>;
  /**
   * Replan only after authoritative evidence binds the exact failed/absent tx
   * and confirms every input unspent. A ProofReady operation additionally
   * requires its current, unexpired manager-owned leaseToken; Submitted and
   * Unknown reconciliation is lease-free because those states clear the worker
   * lease.
   */
  markBroadcastFailed(
    reservationIDs: readonly string[],
    metadata: ReservationLeaseMetadata & ReservationBroadcastFailureEvidence
  ): Promise<NoteReservationRecord[]>;
  /**
   * Restart-safe recovery for an expired foreign ProofReady lease. The exact
   * operation, stored transaction identity, positive checked height, literal
   * execution-failure evidence, and every input nullifier must all match.
   */
  recoverExpiredProofReadyBroadcastFailure(input: ExpiredProofReadyBroadcastFailureRecovery): Promise<NoteReservationRecord[]>;
  /** Records a copied relay payload without exposing a generic same-status metadata patch. */
  recordRelayHandoff(reservationIDs: readonly string[], metadata: ReservationLeaseMetadata & (
    | { payloadHash: string; payload_hash?: string }
    | { payload_hash: string; payloadHash?: string }
  ) & {
    txBytesHash?: string;
    tx_bytes_hash?: string;
    signDocHash?: string;
    sign_doc_hash?: string;
    handedOffAt?: string;
    handed_off_at?: string;
    metadata?: ReservationMetadata;
  }): Promise<NoteReservationRecord[]>;
  /**
   * Lease-independent restart recovery for an already included relay
   * transaction. It accepts either the exact handed-off operation or a durable
   * same-origin local-relay broadcast attempt, binds it to Submitted only, and
   * never marks success or releases notes.
   */
  recordRelayTransactionEvidence(evidence: ReservationRelayTransactionEvidence): Promise<NoteReservationRecord[]>;
  markReplanRequired(reservationIDs?: readonly string[], metadata?: ReservationReplanMetadata): Promise<NoteReservationRecord[]>;
  markManualReview(reservationIDs?: readonly string[], metadata?: ReservationLeaseMetadata & ReservationDurableErrorMetadata & {
    metadata?: ReservationMetadata;
  }): Promise<NoteReservationRecord[]>;
  resolveManualReview(reservationIDs: readonly string[], resolution: ReservationManualReviewResolution): Promise<NoteReservationRecord[]>;
  /**
   * Compatibility name retained for API stability. Automatic release is
   * accepted only while every reservation is still Reserved; Proving and
   * ProofReady must be reconciled or quarantined instead.
   */
  releaseReservedOrProving(reservationIDs?: readonly string[], metadata?: ReservationLeaseMetadata): Promise<NoteReservationRecord[]>;
  reconcileSpentNotes(notes?: readonly (object | FoundNote)[]): Promise<NoteReservationRecord[]>;
}

export declare function createNoteReservationManager(options: NoteReservationManagerInput): NoteReservationManager;
export declare function preparePlanReservation(reservationManager: NoteReservationManager | null | undefined, input?: { plan?: TransferPlan | TransferBatchPlan | WithdrawPlan | object | null; kind?: string; metadata?: ReservationMetadata }): Promise<ReservationBatch | null>;
/** Releases Reserved work; quarantines Proving/ProofReady work in ManualReview. */
export declare function rollbackPlanReservation(reservationManager: NoteReservationManager | null | undefined, batch: ReservationBatch | null | undefined): Promise<void>;
/** Attempts rollback without replacing the original prepare/prover error. */
export declare function rollbackPlanReservationPreservingError(reservationManager: NoteReservationManager | null | undefined, batch: ReservationBatch | null | undefined, error: unknown): Promise<void>;
